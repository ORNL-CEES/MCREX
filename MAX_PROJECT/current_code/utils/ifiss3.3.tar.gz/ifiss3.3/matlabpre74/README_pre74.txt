%% compatibility fix for ilu
%% DJS 21/1/2010
function ilu.m replaced luinc.m in Matlab 7.4
and will be called from this directory if ilu.m is not "built-in". 