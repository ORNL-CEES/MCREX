%GOHOME positions command prompt at top level directory
%   IFISS scriptfile: DJS; 25 Septmber 2013.
% Copyright (c) 2005 D.J. Silvester, H.C. Elman, A. Ramage (see readme.m)
cd('/Users/davidsilvester/Desktop/ifiss3.3')
%cd('/home/caas63/ifiss3.3');
%cd('/fs/helios/elman/ifiss/ifiss3.3');
%cd('c:\Documents and Settings\elman\My Documents\MATLAB\ifiss3.3');
