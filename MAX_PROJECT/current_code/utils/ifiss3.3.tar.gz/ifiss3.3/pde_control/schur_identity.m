function x_it=schur_identity(x_it,schurparams)
%SCHUR_IDENTITY Schur complement identity operator for Poisson control
%   x_it = schur_identity(x_it,mparams);
%   input
%          x_it         operand for preconditioning operator
%          mparams      structure defining block preconditioning operator
%   output
%          x_it         result of preconditioning operation
%
%   IFISS function: JWP, DJS, HCE; 29 June 2012.
% Copyright (c) 2012 J.W. Pearson, D.J. Silvester, H.C. Elman, A. Ramage

x_it = x_it;